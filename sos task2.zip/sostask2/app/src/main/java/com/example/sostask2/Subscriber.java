package com.example.sostask2;

import androidx.annotation.Nullable;

public interface Subscriber
{
    void dosomething(@Nullable String message);

}