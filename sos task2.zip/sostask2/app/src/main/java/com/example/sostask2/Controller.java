package com.example.sostask2;
import static android.graphics.BlendMode.COLOR;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.PopupMenu;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class Controller {
    TableLayout tableLayout;
    ConstraintLayout constraintLayout;
    Context context;
    int p1score,p2score,p1Seqinrow,p2Seqinrow=0;
    boolean player1turn=true;
    boolean p1point,p2point=false;

    Topic start,sosSeq,symbolPlaced,playerTurn,maxSeq;
    Broker broker;

    Subscriber playerTurns,playerSymbol,playerSequences,playMaxSequences;

    TextView playerturn,p1sco,p2sco,p1turns,p2turns,p1Os,p2Os,p1Ss,p2Ss,p1Seq,p2Seq,p1maxSeq,p2maxSeq;

    int plays=0;

    public Controller(TableLayout tableLayout, Context context,ConstraintLayout parent)
    {
        this.tableLayout=tableLayout;
        this.context=context;
        constraintLayout=parent;
        broker=Broker.getInstance();

        // region ids
       int id=context.getResources().getIdentifier("playTurn","id",
                context.getPackageName());
       // int id1=context.getResources().getIdentifier("p1score","id",context.getPackageName());
        int id2=context.getResources().getIdentifier("p2score","id",context.getPackageName());

        //endregion

        //region The Stats textviews
        p1sco=constraintLayout.findViewById(R.id.p1score);
        p2sco=constraintLayout.findViewById(R.id.p2score);
        playerturn=constraintLayout.findViewById(R.id.playTurn);
        p1turns=constraintLayout.findViewById((R.id.p1turns));
        p2turns=constraintLayout.findViewById(R.id.p2turns);
        p1Os=constraintLayout.findViewById(R.id.p1Os);
        p2Os=constraintLayout.findViewById(R.id.p2Os);
        p1Ss=constraintLayout.findViewById(R.id.p1Ss);
        p2Ss=constraintLayout.findViewById(R.id.p2Ss);
        p1Seq=constraintLayout.findViewById(R.id.p1Seq);
        p2Seq=constraintLayout.findViewById(R.id.p2Seq);
        p1maxSeq=constraintLayout.findViewById(R.id.p1maxSeq);
        p2maxSeq=constraintLayout.findViewById(R.id.p2maxSeq);
        //endregion

        //region Topics
        start=new Topic("Game Beginning");
        playerTurn=new Topic("Player Turn");
        sosSeq=new Topic("Sos Sequences");
        symbolPlaced=new Topic("Symbol Placed");
        broker.addtopic(start);
        broker.addtopic(playerTurn);
        broker.addtopic(sosSeq);
        broker.addtopic(symbolPlaced);
        broker.addtopic(maxSeq);
        //endregion


        subscriptions();
        broker.Publish(playerTurn,context.getString(R.string.p1turn));

        setonClick();

    }

    public void setonClick()
    {
        for(int i=0;i<tableLayout.getChildCount();i++)
        {
            TableRow tableRow = (TableRow) tableLayout.getChildAt(i);
            tableRow.setTag(i);

            for(int j=0;j<tableRow.getChildCount();j++)
            {
                Button childView = (Button) tableRow.getChildAt(j);

                //save r and c coordinate of button
                int [] pos={i,j,0};

                childView.setTag(pos); //unchanged color

                childView.setOnClickListener(e->
                        {shopPopup(childView);
                        }
                );

            }

        }
    }

    public void shopPopup(Button button)
    {
        PopupMenu popup=new PopupMenu(context,button);

        popup.getMenuInflater().inflate(R.menu.options, popup.getMenu());
        popup.show();

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.s:
                            Toast.makeText(context, "Selected: S", Toast.LENGTH_SHORT).show();
                            button.setText("S");
                            plays++;
                            broker.Publish(symbolPlaced,context.getString(R.string.placed_S));
                            button.setClickable(false);
                            if(!checkSPoint((int[]) button.getTag(),button))
                            {changeTextview();
                                p1Seqinrow=0;
                                p2Seqinrow=0;
                                p1point=false;
                                p2point=false;

                            }
                            else broker.Publish(sosSeq,context.getString(R.string.sos_complete));
                            showWinner();

                        return true;
                    case R.id.o:
                            Toast.makeText(context, "Selected: O", Toast.LENGTH_SHORT).show();
                            button.setText("O");
                            plays++;
                            broker.Publish(symbolPlaced,context.getString(R.string.placed_O));
                            button.setClickable(false);
                           if(!checkOPoint((int[]) button.getTag(), button)){
                               changeTextview();
                               p1Seqinrow=0;
                               p2Seqinrow=0;
                               p1point=false;
                               p2point=false;
                           }
                           else broker.Publish(sosSeq,context.getString(R.string.sos_complete));
                            showWinner();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    public void changeTextview()
    {
        if(player1turn) //If p1 didn't get a point
        {
                player1turn=false;
                playerturn.setText(R.string.p2turn);
                broker.Publish(playerTurn,context.getString(R.string.p2turn));

        }
        else
        {
                player1turn=true;
                playerturn.setText(R.string.p1turn);
                broker.Publish(playerTurn,context.getString(R.string.p1turn));

        }
    }

    public boolean checkSPoint(int [] pos, Button main)
    {
        boolean found=false;
        //region adresses for diagonal neighbours
        int[] posup={pos[0]-1,pos[1]+1}; //1 up , 1 right

        int[] posup1={pos[0]-2,pos[1]+2}; //2 up , 2 right

        int [] posup2 ={pos[0]-1,pos[1]-1}; //1 up, 1 left

        int [] posup3={pos[0]-2,pos[1]-2}; //2 up, 2 left

        int [] posdown={pos[0]+1,pos[1]+1}; //1 down, 1 right

        int[] posdown1={pos[0]+2,pos[1]+2}; //2 down , 2 right

        int [] posdown2={pos[0]+1,pos[1]-1}; //1 down, 1 left

        int [] posdown3={pos[0]+2,pos[1]-2}; //2 down, 2 left

        int[] posupp={pos[0]-1,pos[1]}; //1 up

        int[] posupup={pos[0]-2,pos[1]}; //2 up

        int [] posdownn ={pos[0]+1,pos[1]}; //1 down

        int [] posdownn2={pos[0]+2,pos[1]}; //2 down

        int row=pos[0];
        int col=pos[1];

        //endregion

        // region up, down and diagonal checks
        if(row-2>=0) //check rows above
        {
            TableRow tr1=tableLayout.findViewWithTag(row-1); //1 row up
            TableRow tr2=tableLayout.findViewWithTag(row-2); //2 rows up

            if(col+2<5) //check right
            {
               found= changeFontS(main,posup,posup1,tr1,tr2,found);
            }

            if(col-2>=0) //check left
            {
               found= changeFontS(main,posup2,posup3,tr1,tr2,found);
            }

            //1 up 2 up
         found=changeFontS(main,posupp,posupup,tr1,tr2,found);

        }


        if(row+2<5) //check rows below
        {   TableRow tr1=tableLayout.findViewWithTag(row+1); //1 row down
            TableRow tr2=tableLayout.findViewWithTag(row+2); //2 rows down

            if(col+2<5) //check right
            {
                found=changeFontS(main, posdown,posdown1,tr1,tr2,found);
            }

            if(col-2>=0) //check left
            { found=changeFontS(main,posdown2,posdown3,tr1,tr2,found);

            }
           found= changeFontS(main,posdownn,posdownn2,tr1,tr2,found);
        }

        //endregion

        //region straight checks

        int [] posleft={pos[0],pos[1]-1}; //1 left

        int [] posleft2={pos[0],pos[1]-2}; //2 left

        int [] posright={pos[0],pos[1]+1}; //1 right

        int [] posright2={pos[0],pos[1]+2}; //2 right
        // endregion

        if(col+2<5) //check right side
        {
            TableRow tableRow=tableLayout.findViewWithTag(row);

            found=changeFontS(main,posright,posright2,tableRow,tableRow,found);
        }

        if(col-2>=0) //check left side
        {
            TableRow tableRow=tableLayout.findViewWithTag(row);

            found=changeFontS(main,posleft,posleft2,tableRow,tableRow,found);
        }

       return found;
    }

    private boolean checkOPoint(int[] pos, Button main) {
        boolean found=false;
        //region addresses
        int row = pos[0];
        int col = pos[1];
        int[] posdownn = {pos[0] + 1, pos[1]}; //1 down
        int[] posupp = {pos[0] - 1, pos[1]}; //1 up
        int[] posup2 = {pos[0] - 1, pos[1] - 1}; //1 up, 1 left
        int[] posdown2 = {pos[0] + 1, pos[1] - 1}; //1 down, 1 left
        int[] posdown = {pos[0] + 1, pos[1] + 1}; //1 down, 1 right
        int[] posup = {pos[0] - 1, pos[1] + 1}; //1 up , 1 right

        int[] posleft = {pos[0], pos[1] - 1}; //1 left

        int[] posright = {pos[0], pos[1] + 1}; //1 right

        //endregion

        if ((row - 1) >= 0 && (row + 1) < 5) //up and down
        {
            TableRow tr1 = tableLayout.findViewWithTag(row - 1);
            TableRow tr2 = tableLayout.findViewWithTag(row + 1);
            TableRow tableRow = tableLayout.findViewWithTag(row);

            found=changeFontO(main, posupp, posdownn, tr1, tr2,found);

            if (col - 1 >= 0 && col + 1 < 5) //check right and left
            {
                found=changeFontO(main, posup2, posdown, tr1, tr2,found);
               found= changeFontO(main, posup, posdown2, tr1, tr2,found);
              found=  changeFontO(main, posleft, posright, tableRow, tableRow,found);
            }

        }

        if (col + 1 < 5 && col - 1 >= 0) //check left and right
        {
            TableRow tableRow = tableLayout.findViewWithTag(row);
           found= changeFontO(main, posleft, posright, tableRow, tableRow,found);

        }

        return found;

    }

    public boolean changeFontS(Button main, int [] pos, int [] pos1,TableRow tr1, TableRow tr2,boolean found)
    {
        int id= context.getResources().getIdentifier("_"+pos[0]+pos[1],"id", context.getPackageName());
        int id1=context.getResources().getIdentifier("_"+pos1[0]+pos1[1],"id", context.getPackageName());

        Button button =tr1.findViewById(id);
        Button button1=tr2.findViewById(id1);

        if(button.getText().equals("O")&&(button1.getText().equals("S"))) //if there's a sequence
        {   found=true;
            ArrayList <Button> buttons=new ArrayList<>();
            buttons.add(button);
            buttons.add(button1);
            buttons.add(main);

            if(player1turn) //if it's player ones turn
            {
                for (Button btn: buttons)
                {
                    int [] tag= (int[]) btn.getTag();

                    if(tag[2]==0) //if belongs to no player
                    {
                        btn.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        int [] desc={tag[0],tag[1],1};
                        btn.setTag(desc);
                    }

                    else if(tag[2]==2) //if belongs to player2
                    {
                        btn.setBackgroundTintList(ColorStateList.valueOf(Color.MAGENTA));
                        int [] desc={tag[0],tag[1],3};
                        btn.setTag(desc);
                    }


                }
                p1score++;


            }

            else
            {
                for (Button btn: buttons)
                {
                    int [] tag= (int[]) btn.getTag();

                    if(tag[2]==0) //if belongs to no player
                    {
                        btn.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        int [] desc={tag[0],tag[1],2};
                        btn.setTag(desc);
                    }

                    else if(tag[2]==1) //if belongs to player1
                    {
                        btn.setBackgroundTintList(ColorStateList.valueOf(Color.MAGENTA));
                        int [] desc={tag[0],tag[1],3};
                        btn.setTag(desc);
                    }


                }

                p2point=true;

            }


        }





        return found;

    }

    public boolean changeFontO(Button main,int [] pos, int [] pos1 , TableRow tr1, TableRow tr2,boolean found)
    {
        int id= context.getResources().getIdentifier("_"+pos[0]+pos[1],"id", context.getPackageName());
        int id1=context.getResources().getIdentifier("_"+pos1[0]+pos1[1],"id", context.getPackageName());

        Button button =tr1.findViewById(id);
        Button button1=tr2.findViewById(id1);
        ArrayList <Button> buttons=new ArrayList<>();

        if(button.getText().equals("S")&&button1.getText().equals("S")) //if there's a sequence
        {   found=true;

            buttons.add(button);
            buttons.add(button1);
            buttons.add(main);

            if(player1turn)
            {

                for (Button btn: buttons)
                {
                    int [] tag= (int[]) btn.getTag();

                    if(tag[2]==0) //if belongs to no player
                    {
                        btn.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        int [] desc={tag[0],tag[1],1};
                        btn.setTag(desc);
                    }

                    else if(tag[2]==2) //if belongs to player2
                    {
                        btn.setBackgroundTintList(ColorStateList.valueOf(Color.MAGENTA));
                        int [] desc={tag[0],tag[1],3};
                        btn.setTag(desc);
                    }

                }

                p1point=true;

            }

            else
            {
                for (Button btn: buttons)
                {
                int [] tag= (int[]) btn.getTag();

                if(tag[2]==0) //if belongs to no player
                {
                    btn.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                    int [] desc={tag[0],tag[1],2};
                    btn.setTag(desc);
                }

                else if(tag[2]==1) //if belongs to player 1
                {
                    btn.setBackgroundTintList(ColorStateList.valueOf(Color.MAGENTA));
                    int [] desc={tag[0],tag[1],3};
                    btn.setTag(desc);
                }

            }

                p2point=true;
            }

        }

        return found;

    }

    public void subscriptions()
    {
        playerTurns=(m)->
        {
            if(m.equals(context.getString(R.string.p1turn)))
            {
                int turns=Integer.parseInt(p1turns.getText().toString());

                p1turns.setText(String.valueOf(turns+1));
            }

            else p2turns.setText(String.valueOf(Integer.parseInt(p2turns.getText().toString())+1));

        };

        playerSymbol = m->
        {
            if(player1turn)
            {
                if(m.equals(context.getString(R.string.placed_O)))
                {
                    p1Os.setText(String.valueOf(Integer.parseInt(p1Os.getText().toString())+1));
                }

                else p1Ss.setText(String.valueOf(Integer.parseInt(p1Ss.getText().toString())+1));
            }

            else
            {
                if(m.equals(context.getString(R.string.placed_O)))
                {
                    p2Os.setText(String.valueOf(Integer.parseInt(p2Os.getText().toString())+1));
                }
                else p2Ss.setText(String.valueOf(Integer.parseInt(p2Ss.getText().toString())+1));
            }

        };

        playerSequences = message ->
        {
            if(player1turn)
            {

                int seq=(Integer.parseInt(p1Seq.getText().toString())+1);
                p1sco.setText(String.valueOf(seq));
                p1Seq.setText(String.valueOf(seq));
                p1Seqinrow++;
                int max=Integer.parseInt(p1maxSeq.getText().toString());
                if(p1Seqinrow>max)
                {
                    p1maxSeq.setText(String.valueOf(p1Seqinrow));
                }

            }

            else
            {
                int seq=(Integer.parseInt(p2Seq.getText().toString())+1);
                p2sco.setText(String.valueOf(seq));
                p2Seq.setText(String.valueOf(seq));
                p2Seqinrow++;
                int max=Integer.parseInt(p2maxSeq.getText().toString());
                if(p2Seqinrow>max)
                {
                    p2maxSeq.setText(String.valueOf(p2Seqinrow));
                }
            }

        };

        broker.Subscribe(playerTurn,playerTurns);
        broker.Subscribe(symbolPlaced,playerSymbol);
        broker.Subscribe(sosSeq,playerSequences);
        broker.Subscribe(maxSeq,playMaxSequences);

    }

    public void showWinner()
    {
        if(plays==25)
        {
            String winner;
            int p1=Integer.parseInt(p1Seq.getText().toString());
            int p2=Integer.parseInt(p2Seq.getText().toString());
            if(p1>p2)
            {
                winner="Player 1 Wins";
                Intent intent=new Intent(context,EndActivity.class);
                intent.putExtra("winner",winner);
                intent.putExtra("p1score",String.valueOf(p1));
                intent.putExtra("p2score",String.valueOf(p2));
                context.startActivity(intent);

            }

            else if(p2>p1)
            {   winner="Player 2 Wins";
                Intent intent=new Intent(context,EndActivity.class);
                intent.putExtra("winner",winner);
                intent.putExtra("p1score",String.valueOf(p1));
                intent.putExtra("p2score",String.valueOf(p2));
                context.startActivity(intent);
            }

            else
            {
                Intent intent=new Intent(context,Stalemate.class);
                intent.putExtra("p1score",String.valueOf(p1));
                intent.putExtra("p2score",String.valueOf(p2));
                context.startActivity(intent);
            }

        }

    }

}

