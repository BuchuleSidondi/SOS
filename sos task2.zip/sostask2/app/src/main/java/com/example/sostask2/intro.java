package com.example.sostask2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class intro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro);

        Button button=findViewById(R.id.button);

        button.setOnClickListener(l->openPlay());
    }

    public void openPlay()
    {
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}