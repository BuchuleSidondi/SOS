package com.example.sostask2;

import java.util.ArrayList;

public class Topic
{
    private String topic;

    ArrayList<String> messages; //topic can have many messages

    public Topic(String topic) {
        this.topic = topic;
    }

    public ArrayList<String> getMessages()
    {
        return messages;
    }

    public void addMessage(String mess)
    {
        messages.add(mess);
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
