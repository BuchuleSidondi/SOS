package com.example.sostask2;


import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.TableLayout;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        TableLayout tableLayout=findViewById(R.id.playView);
        ConstraintLayout constraintLayout=findViewById(R.id.constraint);
        Controller controller=new Controller(tableLayout,this,constraintLayout);
    }
}