package com.example.sostask2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class EndActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.winner);

        Button button=findViewById(R.id.button3);
        TextView textView=findViewById(R.id.winnerTxrView);

        String id = getIntent().getStringExtra("winner");
        textView.setText(id);

        TextView p1score= findViewById(R.id.p1scorewin);

        TextView p2score= findViewById(R.id.p2scorewin);

        String p1sco = getIntent().getStringExtra("p1score");
        String p2sco = getIntent().getStringExtra("p2score");

        p1score.setText(p1sco);
        p2score.setText(p2sco);
        button.setOnClickListener(l->openPlay());
    }

    public void openPlay()
    {
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}