package com.example.sostask2;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class Broker {

    private static Broker instance=null;

    HashMap<Topic, ArrayList<Subscriber>> subscribers;

    Topic buttontap;

    private Broker()
    {subscribers=new HashMap<>();}

    public void addtopic(Topic topic)
    {
        if(!subscribers.containsKey(topic))
        { subscribers.put(topic,new ArrayList<>());
        }

    }

    public  ArrayList<ArrayList<Subscriber>> getAllSubscribers()
    {
        ArrayList<ArrayList <Subscriber>> subs=new ArrayList<>();

        for (Topic topic : subscribers.keySet())
        {
            subs.add(subscribers.get(topic));
        }

        return subs;
    }

    public static Broker getInstance()
    {
        if(instance==null)
        {instance=new Broker();}
        return instance;
    }

    public void Subscribe(Topic topic, Subscriber subscriber)
    {
        if(subscribers.containsKey(topic)) //if there is such topic
        {
            Objects.requireNonNull(subscribers.get(topic)).add(subscriber);
            System.out.println("Subscribed");
        }
        else System.out.println("No such topic : " + topic.getTopic());
    }

    public void unSubscribe(Topic topic,Subscriber subscriber)
    {
        if(subscribers.containsKey(topic)) //if there is such topic
        {
            ArrayList <Subscriber> subs=subscribers.get(topic);

            if(subs.size()==1&&subscriber.equals(subs.get(0)))
            {subs.remove(0);
                return;
            }

            for (int i=0;i<subs.size();i++)
            {
                if (subscriber.equals(subs.get(i)))
                {
                    subs.remove(i);

                    return;
                }
            }
        }

    }

    public void Publish(Topic topic, @Nullable String message)
    {
        if (subscribers.containsKey(topic))
        {
            //topic.addMessage(message);

            for (Subscriber subscriber : Objects.requireNonNull(subscribers.get(topic)))
            {
                subscriber.dosomething(message);


            }
        }

    }


}
